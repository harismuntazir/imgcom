# imgcom_harismuntazir/__init__.py

# This file makes the imgcom directory a Python package.
# It can be left empty, or you can add initialization code here
# if needed.  For a simple project, an empty file is fine.
